﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaboratoryWork3
{
    public static class InputCommands
    {
        public const string AddFigure = "добавить";
        public const string Sort = "отсортировать";
        public const string PrintAll = "вывести";
        public const string PrintFirstFourTypes = "типы";
        public const string Draw = "нарисовать";
        public const string Serialize = "сериализовать";
        public const string DeSerialize = "десериализовать";
    }
}
